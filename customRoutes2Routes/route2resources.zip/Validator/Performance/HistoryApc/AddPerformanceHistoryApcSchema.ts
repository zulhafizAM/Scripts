import { z } from 'zod';

const AddPerformanceHistoryApcSchema = z
    .object({
    })

export default AddPerformanceHistoryApcSchema;
