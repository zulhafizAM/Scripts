import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext';
import { inject } from '@adonisjs/core/build/standalone';
import BaseController from './BaseController';
import { error, fail, success } from 'App/Models/DTO/Shared/DefaultResponse';import PerformanceLnptServices from 'App/Services/Performance/PerformanceLnptServices';
import PerformanceAverageLnptServices from 'App/Services/Performance/PerformanceAverageLnptServices';
import PerformanceHireLnptServices from 'App/Services/Performance/PerformanceHireLnptServices';
import PerformanceHireAverageLnptServices from 'App/Services/Performance/PerformanceHireAverageLnptServices';
import PerformanceHistoryServices from 'App/Services/Performance/PerformanceHistoryServices';
import PerformanceHistoryPersonalDetailServices from 'App/Services/Performance/PerformanceHistoryPersonalDetailServices';
import PerformanceHistoryServiceDetailServices from 'App/Services/Performance/PerformanceHistoryServiceDetailServices';
import PerformanceHistoryApcServices from 'App/Services/Performance/PerformanceHistoryApcServices';
import GetByIdSchema from 'App/Validators/Shared/GetByIdValidator';
import ListPerformanceLnptSchema from 'App/Validators/Performance/Lnpt/ListPerformanceLnptSchema';
import ListPerformanceAverageLnptSchema from 'App/Validators/Performance/AverageLnpt/ListPerformanceAverageLnptSchema';
import ListPerformanceHireLnptSchema from 'App/Validators/Performance/HireLnpt/ListPerformanceHireLnptSchema';
import ListPerformanceHireAverageLnptSchema from 'App/Validators/Performance/HireAverageLnpt/ListPerformanceHireAverageLnptSchema';
import ListPerformanceHistorySchema from 'App/Validators/Performance/History/ListPerformanceHistorySchema';
import AddPerformanceHistoryApcSchema from 'App/Validators/Performance/HistoryApc/AddPerformanceHistoryApcSchema';

@inject()
export default class PerformancesController extends BaseController {
    constructor(
        private performanceLnptService: PerformanceLnptServices,
        private performanceAverageLnptService: PerformanceAverageLnptServices,
        private performanceHireLnptService: PerformanceHireLnptServices,
        private performanceHireAverageLnptService: PerformanceHireAverageLnptServices,
        private performanceHistoryService: PerformanceHistoryServices,
        private performanceHistoryPersonalDetailService: PerformanceHistoryPersonalDetailServices,
        private performanceHistoryServiceDetailService: PerformanceHistoryServiceDetailServices,
        private performanceHistoryApcService: PerformanceHistoryApcServices,
        ) {
        super();
    }

    public async getLnpts({ request, response }: HttpContextContract) {
        try {
            const requestParams = request.body();
            const validationResult =
                LnptsListFilterSchema.safeParse(requestParams);

            if (!validationResult.success) {
                return response
                    .status(400)
                    .send(fail(validationResult.error.errors));
            }

            const result =
                await this.performanceLnptService.getLnpts(requestParams);
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getAverageLnpts({ request, response }: HttpContextContract) {
        try {
            const requestParams = request.body();
            const validationResult =
                AverageLnptsListFilterSchema.safeParse(requestParams);

            if (!validationResult.success) {
                return response
                    .status(400)
                    .send(fail(validationResult.error.errors));
            }

            const result =
                await this.performanceAverageLnptService.getAverageLnpts(requestParams);
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getAverageLnpt({ request, response }: HttpContextContract) {
        const data = request.body();
        let validate = GetByIdSchema.safeParse(data);
        try {
            if (!validate.success)
                return response.status(400).send(fail(validate.error.errors));
            const result = await this.performanceAverageLnptService.getAverageLnpt(
                data.averageLnptId,
            );
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getHireLnpts({ request, response }: HttpContextContract) {
        try {
            const requestParams = request.body();
            const validationResult =
                HireLnptsListFilterSchema.safeParse(requestParams);

            if (!validationResult.success) {
                return response
                    .status(400)
                    .send(fail(validationResult.error.errors));
            }

            const result =
                await this.performanceHireLnptService.getHireLnpts(requestParams);
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getHireAverageLnpts({ request, response }: HttpContextContract) {
        try {
            const requestParams = request.body();
            const validationResult =
                HireAverageLnptsListFilterSchema.safeParse(requestParams);

            if (!validationResult.success) {
                return response
                    .status(400)
                    .send(fail(validationResult.error.errors));
            }

            const result =
                await this.performanceHireAverageLnptService.getHireAverageLnpts(requestParams);
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getHireAverageLnpt({ request, response }: HttpContextContract) {
        const data = request.body();
        let validate = GetByIdSchema.safeParse(data);
        try {
            if (!validate.success)
                return response.status(400).send(fail(validate.error.errors));
            const result = await this.performanceHireAverageLnptService.getHireAverageLnpt(
                data.hireAverageLnptId,
            );
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getHistorys({ request, response }: HttpContextContract) {
        try {
            const requestParams = request.body();
            const validationResult =
                HistorysListFilterSchema.safeParse(requestParams);

            if (!validationResult.success) {
                return response
                    .status(400)
                    .send(fail(validationResult.error.errors));
            }

            const result =
                await this.performanceHistoryService.getHistorys(requestParams);
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getHistoryPersonalDetail({ request, response }: HttpContextContract) {
        const data = request.body();
        let validate = GetByIdSchema.safeParse(data);
        try {
            if (!validate.success)
                return response.status(400).send(fail(validate.error.errors));
            const result = await this.performanceHistoryPersonalDetailService.getHistoryPersonalDetail(
                data.historyPersonalDetailId,
            );
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }
    public async getHistoryServiceDetail({ request, response }: HttpContextContract) {
        const data = request.body();
        let validate = GetByIdSchema.safeParse(data);
        try {
            if (!validate.success)
                return response.status(400).send(fail(validate.error.errors));
            const result = await this.performanceHistoryServiceDetailService.getHistoryServiceDetail(
                data.historyServiceDetailId,
            );
            return response.status(200).send(success(result));
        } catch (e) {
            return response
                .status(409)
                .send(error('An error occured while processing your request'));
        }
    }

    public async addHistoryApc({ request }: HttpContextContract) {
        return this.validateAndProcessRequest(
            request,
            this.performanceHistoryApcService.addHistoryApc,
            AddPerformanceHistoryApcSchema,
        );
    }

}
