const performanceModule = [
    { routeName: 'lnpt', actions: ['list'] },
    { routeName: 'average-lnpt', actions: ['list', 'get'] },
    { routeName: 'hire-lnpt', actions: ['list'] },
    { routeName: 'hire-average-lnpt', actions: ['list', 'get'] },
    { routeName: 'history', actions: ['list'] },
    { routeName: 'history-personal-detail', actions: ['get'] },
    { routeName: 'history-service-detail', actions: ['get'] },
    { routeName: 'history-apc', actions: ['add'] },
];