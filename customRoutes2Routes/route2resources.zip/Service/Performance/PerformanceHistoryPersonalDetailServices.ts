import Database from '@ioc:Adonis/Lucid/Database';
import GetPerformanceHistoryPersonalDetailResponse, { PerformanceHistoryPersonalDetailResponse } from 'App/Models/DTO/Employments/Performance/HistoryPersonalDetail/GetPerformanceHistoryPersonalDetailResponse';
import HistoryPersonalDetail from 'App/Models/HistoryPersonalDetail';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceHistoryPersonalDetailServices extends BaseService {
    public async getHistoryPersonalDetail(
        historyPersonalDetailId: number,
    ): Promise<DefaultDataResponse<PerformanceHistoryPersonalDetailResponse>> {
        let historyPersonalDetail = new DefaultDataResponse<PerformanceHistoryPersonalDetailResponse>();
        const readHistoryPersonalDetail = await HistoryPersonalDetail.query()
            .where('id', historyPersonalDetailId)
            .firstOrFail();
        historyPersonalDetail = {
            details: {
                historyPersonalDetailId: readHistoryPersonalDetail.id,
            },
        };
        return historyPersonalDetail;
    }
}
