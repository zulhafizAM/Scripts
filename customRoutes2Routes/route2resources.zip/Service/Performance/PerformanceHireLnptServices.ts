import Database from '@ioc:Adonis/Lucid/Database';
import { PerformanceHireLnptsResponse } from 'App/Models/DTO/Employments/Performance/HireLnpt/ListPerformanceHireLnptResponse';
import HireLnpt from 'App/Models/HireLnpt';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceHireLnptServices extends BaseService {
    public async getHireLnpts(
        payload,
    ): Promise<DefaultListResponse<PerformanceHireLnptResponse>> {
        let hireLnpts = new DefaultListResponse<PerformanceHireLnptResponse>();
        const HireLnptList = await HireLnpt.query()
        hireLnpts = {
            meta: {
                pageNum: payload.pageNum,
                totalData: HireLnptList.length,
                totalPage: Math.ceil(HireLnptList.length / payload.pageSize),
                pageSize: 0,
            },
            dataList: HireLnptList.map((result) => ({
            })),
        };

        if (payload.orderBy !== null && payload.orderBy !== '') {
            this.ordering(payload, hireLnpts, 'dataList');
        }

        hireLnpts.dataList = hireLnpts.dataList.slice(
            (payload.pageNum - 1) * payload.pageSize,
            payload.pageNum * payload.pageSize,
        );
        hireLnpts.meta!.pageSize = hireLnpts.dataList.length;
        return hireLnpts;
    }
}
