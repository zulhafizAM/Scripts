import Database from '@ioc:Adonis/Lucid/Database';
import { PerformanceHireAverageLnptsResponse } from 'App/Models/DTO/Employments/Performance/HireAverageLnpt/ListPerformanceHireAverageLnptResponse';
import GetPerformanceHireAverageLnptResponse, { PerformanceHireAverageLnptResponse } from 'App/Models/DTO/Employments/Performance/HireAverageLnpt/GetPerformanceHireAverageLnptResponse';
import HireAverageLnpt from 'App/Models/HireAverageLnpt';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceHireAverageLnptServices extends BaseService {
    public async getHireAverageLnpts(
        payload,
    ): Promise<DefaultListResponse<PerformanceHireAverageLnptResponse>> {
        let hireAverageLnpts = new DefaultListResponse<PerformanceHireAverageLnptResponse>();
        const HireAverageLnptList = await HireAverageLnpt.query()
        hireAverageLnpts = {
            meta: {
                pageNum: payload.pageNum,
                totalData: HireAverageLnptList.length,
                totalPage: Math.ceil(HireAverageLnptList.length / payload.pageSize),
                pageSize: 0,
            },
            dataList: HireAverageLnptList.map((result) => ({
            })),
        };

        if (payload.orderBy !== null && payload.orderBy !== '') {
            this.ordering(payload, hireAverageLnpts, 'dataList');
        }

        hireAverageLnpts.dataList = hireAverageLnpts.dataList.slice(
            (payload.pageNum - 1) * payload.pageSize,
            payload.pageNum * payload.pageSize,
        );
        hireAverageLnpts.meta!.pageSize = hireAverageLnpts.dataList.length;
        return hireAverageLnpts;
    }
    public async getHireAverageLnpt(
        hireAverageLnptId: number,
    ): Promise<DefaultDataResponse<PerformanceHireAverageLnptResponse>> {
        let hireAverageLnpt = new DefaultDataResponse<PerformanceHireAverageLnptResponse>();
        const readHireAverageLnpt = await HireAverageLnpt.query()
            .where('id', hireAverageLnptId)
            .firstOrFail();
        hireAverageLnpt = {
            details: {
                hireAverageLnptId: readHireAverageLnpt.id,
            },
        };
        return hireAverageLnpt;
    }
}
