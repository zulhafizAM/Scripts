import Database from '@ioc:Adonis/Lucid/Database';
import HistoryApc from 'App/Models/HistoryApc';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceHistoryApcServices extends BaseService {
    public async addHistoryApc(payload): Promise<void> {
        const transaction = await Database.transaction();
        try {
            let historyApc = new HistoryApc();

            await historyApc.save();

            await transaction.commit();
        } catch (error) {
            await transaction.rollback();
            console.log(error);
            throw error;
        }
    }
}
