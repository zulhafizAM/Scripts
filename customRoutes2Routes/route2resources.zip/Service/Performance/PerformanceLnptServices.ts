import Database from '@ioc:Adonis/Lucid/Database';
import { PerformanceLnptsResponse } from 'App/Models/DTO/Employments/Performance/Lnpt/ListPerformanceLnptResponse';
import Lnpt from 'App/Models/Lnpt';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceLnptServices extends BaseService {
    public async getLnpts(
        payload,
    ): Promise<DefaultListResponse<PerformanceLnptResponse>> {
        let lnpts = new DefaultListResponse<PerformanceLnptResponse>();
        const LnptList = await Lnpt.query()
        lnpts = {
            meta: {
                pageNum: payload.pageNum,
                totalData: LnptList.length,
                totalPage: Math.ceil(LnptList.length / payload.pageSize),
                pageSize: 0,
            },
            dataList: LnptList.map((result) => ({
            })),
        };

        if (payload.orderBy !== null && payload.orderBy !== '') {
            this.ordering(payload, lnpts, 'dataList');
        }

        lnpts.dataList = lnpts.dataList.slice(
            (payload.pageNum - 1) * payload.pageSize,
            payload.pageNum * payload.pageSize,
        );
        lnpts.meta!.pageSize = lnpts.dataList.length;
        return lnpts;
    }
}
