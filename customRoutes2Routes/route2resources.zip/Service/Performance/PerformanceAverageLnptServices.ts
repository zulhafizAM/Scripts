import Database from '@ioc:Adonis/Lucid/Database';
import { PerformanceAverageLnptsResponse } from 'App/Models/DTO/Employments/Performance/AverageLnpt/ListPerformanceAverageLnptResponse';
import GetPerformanceAverageLnptResponse, { PerformanceAverageLnptResponse } from 'App/Models/DTO/Employments/Performance/AverageLnpt/GetPerformanceAverageLnptResponse';
import AverageLnpt from 'App/Models/AverageLnpt';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceAverageLnptServices extends BaseService {
    public async getAverageLnpts(
        payload,
    ): Promise<DefaultListResponse<PerformanceAverageLnptResponse>> {
        let averageLnpts = new DefaultListResponse<PerformanceAverageLnptResponse>();
        const AverageLnptList = await AverageLnpt.query()
        averageLnpts = {
            meta: {
                pageNum: payload.pageNum,
                totalData: AverageLnptList.length,
                totalPage: Math.ceil(AverageLnptList.length / payload.pageSize),
                pageSize: 0,
            },
            dataList: AverageLnptList.map((result) => ({
            })),
        };

        if (payload.orderBy !== null && payload.orderBy !== '') {
            this.ordering(payload, averageLnpts, 'dataList');
        }

        averageLnpts.dataList = averageLnpts.dataList.slice(
            (payload.pageNum - 1) * payload.pageSize,
            payload.pageNum * payload.pageSize,
        );
        averageLnpts.meta!.pageSize = averageLnpts.dataList.length;
        return averageLnpts;
    }
    public async getAverageLnpt(
        averageLnptId: number,
    ): Promise<DefaultDataResponse<PerformanceAverageLnptResponse>> {
        let averageLnpt = new DefaultDataResponse<PerformanceAverageLnptResponse>();
        const readAverageLnpt = await AverageLnpt.query()
            .where('id', averageLnptId)
            .firstOrFail();
        averageLnpt = {
            details: {
                averageLnptId: readAverageLnpt.id,
            },
        };
        return averageLnpt;
    }
}
