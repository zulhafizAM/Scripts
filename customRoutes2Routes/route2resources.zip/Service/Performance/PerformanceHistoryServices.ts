import Database from '@ioc:Adonis/Lucid/Database';
import { PerformanceHistorysResponse } from 'App/Models/DTO/Employments/Performance/History/ListPerformanceHistoryResponse';
import History from 'App/Models/History';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceHistoryServices extends BaseService {
    public async getHistorys(
        payload,
    ): Promise<DefaultListResponse<PerformanceHistoryResponse>> {
        let historys = new DefaultListResponse<PerformanceHistoryResponse>();
        const HistoryList = await History.query()
        historys = {
            meta: {
                pageNum: payload.pageNum,
                totalData: HistoryList.length,
                totalPage: Math.ceil(HistoryList.length / payload.pageSize),
                pageSize: 0,
            },
            dataList: HistoryList.map((result) => ({
            })),
        };

        if (payload.orderBy !== null && payload.orderBy !== '') {
            this.ordering(payload, historys, 'dataList');
        }

        historys.dataList = historys.dataList.slice(
            (payload.pageNum - 1) * payload.pageSize,
            payload.pageNum * payload.pageSize,
        );
        historys.meta!.pageSize = historys.dataList.length;
        return historys;
    }
}
