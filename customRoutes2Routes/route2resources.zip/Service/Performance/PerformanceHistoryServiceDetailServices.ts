import Database from '@ioc:Adonis/Lucid/Database';
import GetPerformanceHistoryServiceDetailResponse, { PerformanceHistoryServiceDetailResponse } from 'App/Models/DTO/Employments/Performance/HistoryServiceDetail/GetPerformanceHistoryServiceDetailResponse';
import HistoryServiceDetail from 'App/Models/HistoryServiceDetail';
import BaseService from 'App/Services/Shared/BaseService';
export default class PerformanceHistoryServiceDetailServices extends BaseService {
    public async getHistoryServiceDetail(
        historyServiceDetailId: number,
    ): Promise<DefaultDataResponse<PerformanceHistoryServiceDetailResponse>> {
        let historyServiceDetail = new DefaultDataResponse<PerformanceHistoryServiceDetailResponse>();
        const readHistoryServiceDetail = await HistoryServiceDetail.query()
            .where('id', historyServiceDetailId)
            .firstOrFail();
        historyServiceDetail = {
            details: {
                historyServiceDetailId: readHistoryServiceDetail.id,
            },
        };
        return historyServiceDetail;
    }
}
