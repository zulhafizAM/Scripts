export default class PerformanceAverageLnptResponse {
}
