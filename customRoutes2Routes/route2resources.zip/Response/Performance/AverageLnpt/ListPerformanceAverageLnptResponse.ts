export default class PerformanceAverageLnptsResponse {
    public id: number;
}
