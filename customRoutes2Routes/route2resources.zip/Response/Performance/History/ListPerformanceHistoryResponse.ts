export default class PerformanceHistorysResponse {
    public id: number;
}
