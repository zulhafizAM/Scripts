export default class PerformanceHireAverageLnptsResponse {
    public id: number;
}
