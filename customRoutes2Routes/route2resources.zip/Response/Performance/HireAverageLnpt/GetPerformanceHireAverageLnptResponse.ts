export default class PerformanceHireAverageLnptResponse {
}
