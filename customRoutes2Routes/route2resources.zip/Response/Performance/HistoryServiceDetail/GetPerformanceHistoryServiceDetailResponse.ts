export default class PerformanceHistoryServiceDetailResponse {
}
