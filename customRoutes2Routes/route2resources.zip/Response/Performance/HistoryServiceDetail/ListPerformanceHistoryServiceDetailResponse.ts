export default class PerformanceHistoryServiceDetailsResponse {
    public id: number;
}
