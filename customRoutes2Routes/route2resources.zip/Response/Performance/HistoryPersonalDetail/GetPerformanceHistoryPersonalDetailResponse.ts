export default class PerformanceHistoryPersonalDetailResponse {
}
