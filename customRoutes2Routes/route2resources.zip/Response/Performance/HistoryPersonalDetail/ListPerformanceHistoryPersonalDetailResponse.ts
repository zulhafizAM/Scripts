export default class PerformanceHistoryPersonalDetailsResponse {
    public id: number;
}
