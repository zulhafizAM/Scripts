export default class PerformanceLnptsResponse {
    public id: number;
}
