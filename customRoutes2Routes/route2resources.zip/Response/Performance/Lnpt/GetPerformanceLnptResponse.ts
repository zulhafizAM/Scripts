export default class PerformanceLnptResponse {
}
