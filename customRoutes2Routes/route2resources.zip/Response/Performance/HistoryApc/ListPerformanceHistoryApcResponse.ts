export default class PerformanceHistoryApcsResponse {
    public id: number;
}
