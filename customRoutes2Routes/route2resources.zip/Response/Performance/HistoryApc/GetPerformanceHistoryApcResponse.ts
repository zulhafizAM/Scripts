export default class PerformanceHistoryApcResponse {
}
