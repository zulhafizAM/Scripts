export default class PerformanceHireLnptResponse {
}
