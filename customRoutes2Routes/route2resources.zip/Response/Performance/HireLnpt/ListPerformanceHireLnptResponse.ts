export default class PerformanceHireLnptsResponse {
    public id: number;
}
